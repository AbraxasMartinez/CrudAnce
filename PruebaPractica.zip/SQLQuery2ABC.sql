USE [master]
GO
/****** Object:  Database [ABC]    Script Date: 13/09/2022 03:29:24 a. m. ******/
CREATE DATABASE [ABC]
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N'ABC', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL15.MSSQLSERVER\MSSQL\DATA\ABC.mdf' , SIZE = 8192KB , MAXSIZE = UNLIMITED, FILEGROWTH = 65536KB )
 LOG ON 
( NAME = N'ABC_log', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL15.MSSQLSERVER\MSSQL\DATA\ABC_log.ldf' , SIZE = 8192KB , MAXSIZE = 2048GB , FILEGROWTH = 65536KB )
 WITH CATALOG_COLLATION = DATABASE_DEFAULT
GO
ALTER DATABASE [ABC] SET COMPATIBILITY_LEVEL = 150
GO
IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
begin
EXEC [ABC].[dbo].[sp_fulltext_database] @action = 'enable'
end
GO
ALTER DATABASE [ABC] SET ANSI_NULL_DEFAULT OFF 
GO
ALTER DATABASE [ABC] SET ANSI_NULLS OFF 
GO
ALTER DATABASE [ABC] SET ANSI_PADDING OFF 
GO
ALTER DATABASE [ABC] SET ANSI_WARNINGS OFF 
GO
ALTER DATABASE [ABC] SET ARITHABORT OFF 
GO
ALTER DATABASE [ABC] SET AUTO_CLOSE OFF 
GO
ALTER DATABASE [ABC] SET AUTO_SHRINK OFF 
GO
ALTER DATABASE [ABC] SET AUTO_UPDATE_STATISTICS ON 
GO
ALTER DATABASE [ABC] SET CURSOR_CLOSE_ON_COMMIT OFF 
GO
ALTER DATABASE [ABC] SET CURSOR_DEFAULT  GLOBAL 
GO
ALTER DATABASE [ABC] SET CONCAT_NULL_YIELDS_NULL OFF 
GO
ALTER DATABASE [ABC] SET NUMERIC_ROUNDABORT OFF 
GO
ALTER DATABASE [ABC] SET QUOTED_IDENTIFIER OFF 
GO
ALTER DATABASE [ABC] SET RECURSIVE_TRIGGERS OFF 
GO
ALTER DATABASE [ABC] SET  DISABLE_BROKER 
GO
ALTER DATABASE [ABC] SET AUTO_UPDATE_STATISTICS_ASYNC OFF 
GO
ALTER DATABASE [ABC] SET DATE_CORRELATION_OPTIMIZATION OFF 
GO
ALTER DATABASE [ABC] SET TRUSTWORTHY OFF 
GO
ALTER DATABASE [ABC] SET ALLOW_SNAPSHOT_ISOLATION OFF 
GO
ALTER DATABASE [ABC] SET PARAMETERIZATION SIMPLE 
GO
ALTER DATABASE [ABC] SET READ_COMMITTED_SNAPSHOT OFF 
GO
ALTER DATABASE [ABC] SET HONOR_BROKER_PRIORITY OFF 
GO
ALTER DATABASE [ABC] SET RECOVERY FULL 
GO
ALTER DATABASE [ABC] SET  MULTI_USER 
GO
ALTER DATABASE [ABC] SET PAGE_VERIFY CHECKSUM  
GO
ALTER DATABASE [ABC] SET DB_CHAINING OFF 
GO
ALTER DATABASE [ABC] SET FILESTREAM( NON_TRANSACTED_ACCESS = OFF ) 
GO
ALTER DATABASE [ABC] SET TARGET_RECOVERY_TIME = 60 SECONDS 
GO
ALTER DATABASE [ABC] SET DELAYED_DURABILITY = DISABLED 
GO
ALTER DATABASE [ABC] SET ACCELERATED_DATABASE_RECOVERY = OFF  
GO
EXEC sys.sp_db_vardecimal_storage_format N'ABC', N'ON'
GO
ALTER DATABASE [ABC] SET QUERY_STORE = OFF
GO
USE [ABC]
GO
/****** Object:  User [usrTest]    Script Date: 13/09/2022 03:29:25 a. m. ******/
CREATE USER [usrTest] FOR LOGIN [usrTest] WITH DEFAULT_SCHEMA=[dbo]
GO
/****** Object:  UserDefinedDataType [dbo].[info]    Script Date: 13/09/2022 03:29:25 a. m. ******/
CREATE TYPE [dbo].[info] FROM [varchar](50) NOT NULL
GO
/****** Object:  UserDefinedDataType [dbo].[informacion]    Script Date: 13/09/2022 03:29:25 a. m. ******/
CREATE TYPE [dbo].[informacion] FROM [varchar](50) NOT NULL
GO
/****** Object:  Table [dbo].[Areas]    Script Date: 13/09/2022 03:29:25 a. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Areas](
	[idArea] [int] NOT NULL,
	[Nombre_Area] [dbo].[informacion] NULL,
	[Division_Area] [tinyint] NULL,
	[Detalles_del_Area] [dbo].[informacion] NULL,
 CONSTRAINT [PK_Areas] PRIMARY KEY CLUSTERED 
(
	[idArea] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Empleados]    Script Date: 13/09/2022 03:29:26 a. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Empleados](
	[idEmpleado] [int] NOT NULL,
	[Nombre] [dbo].[informacion] NULL,
	[ApellidoPaterno] [dbo].[informacion] NULL,
	[ApellidoMaterno] [dbo].[informacion] NULL,
	[Area] [dbo].[informacion] NULL,
	[Division] [tinyint] NULL,
	[Email] [dbo].[informacion] NULL,
 CONSTRAINT [PK_Empleados] PRIMARY KEY CLUSTERED 
(
	[idEmpleado] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
INSERT [dbo].[Areas] ([idArea], [Nombre_Area], [Division_Area], [Detalles_del_Area]) VALUES (1, N'seguridad', 12, N'cubrir durante 24horas')
GO
INSERT [dbo].[Areas] ([idArea], [Nombre_Area], [Division_Area], [Detalles_del_Area]) VALUES (2, N'limpieza', 3, N'radioactiva')
GO
INSERT [dbo].[Areas] ([idArea], [Nombre_Area], [Division_Area], [Detalles_del_Area]) VALUES (3, N'Informatica', 4, N'Es muy proactiva')
GO
INSERT [dbo].[Areas] ([idArea], [Nombre_Area], [Division_Area], [Detalles_del_Area]) VALUES (4, N'paqueteria', 2, N'finaliza a las 6pm')
GO
INSERT [dbo].[Areas] ([idArea], [Nombre_Area], [Division_Area], [Detalles_del_Area]) VALUES (5, N'Anunciante', 8, N'Ocupa Internet')
GO
INSERT [dbo].[Areas] ([idArea], [Nombre_Area], [Division_Area], [Detalles_del_Area]) VALUES (6, N'Ti', 1, N'Seccion Restringida')
GO
INSERT [dbo].[Areas] ([idArea], [Nombre_Area], [Division_Area], [Detalles_del_Area]) VALUES (7, N'Ciberseguridad', 1, N'Respaldo en Nube')
GO
INSERT [dbo].[Empleados] ([idEmpleado], [Nombre], [ApellidoPaterno], [ApellidoMaterno], [Area], [Division], [Email]) VALUES (0, N'', N'', N'', N'', 0, N'')
GO
INSERT [dbo].[Empleados] ([idEmpleado], [Nombre], [ApellidoPaterno], [ApellidoMaterno], [Area], [Division], [Email]) VALUES (1, N'Abraham David', N'Martinez', N'Olmos', N'Informatica', 1, N'abraham.titanium@gmail.com')
GO
INSERT [dbo].[Empleados] ([idEmpleado], [Nombre], [ApellidoPaterno], [ApellidoMaterno], [Area], [Division], [Email]) VALUES (2, N'josedominicu', N'marinda', N'esquivel', N'Contabilidad', 3, N'abraham.titanium@hotmail.com')
GO
INSERT [dbo].[Empleados] ([idEmpleado], [Nombre], [ApellidoPaterno], [ApellidoMaterno], [Area], [Division], [Email]) VALUES (3, N'Ramon', N'Martinez', N'Olmos', N'Legal', 5, N'ramon.ol@gmail.com')
GO
INSERT [dbo].[Empleados] ([idEmpleado], [Nombre], [ApellidoPaterno], [ApellidoMaterno], [Area], [Division], [Email]) VALUES (4, N'Daniela Fernanda', N'Garcia', N'Perez', N'Recursos Humanos', 2, N'dani.garcia@hotmail.com')
GO
INSERT [dbo].[Empleados] ([idEmpleado], [Nombre], [ApellidoPaterno], [ApellidoMaterno], [Area], [Division], [Email]) VALUES (5, N'Daniela Fernanda', N'Martinez', N'Farfan', N'Recursos Humanos', 3, N'danyy.98@gmail.com')
GO
INSERT [dbo].[Empleados] ([idEmpleado], [Nombre], [ApellidoPaterno], [ApellidoMaterno], [Area], [Division], [Email]) VALUES (6, N'Judith', N'Navarro', N'Martinez', N'Contabilidad', 1, N'jufit@gmail.com')
GO
INSERT [dbo].[Empleados] ([idEmpleado], [Nombre], [ApellidoPaterno], [ApellidoMaterno], [Area], [Division], [Email]) VALUES (7, N'Josh', N'Jimenez', N'Zarate', N'Atención al Cliente', 9, N'golumbia@gmail.com')
GO
INSERT [dbo].[Empleados] ([idEmpleado], [Nombre], [ApellidoPaterno], [ApellidoMaterno], [Area], [Division], [Email]) VALUES (8, N'Magdalena', N'Martinez', N'Palacios', N'Archivo General', 9, N'magda@hotmail.com')
GO
USE [master]
GO
ALTER DATABASE [ABC] SET  READ_WRITE 
GO
