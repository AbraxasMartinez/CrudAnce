<?php
 require_once'base.php';
 include("AltaAreas.php");
 
 $idArea=$_POST["idArea"];
 $Nombre_Area=$_POST["Nombre_Area"];
 $Division_Area=$_POST["Division_Area"];
 $Detalles_del_Area=$_POST["Detalles_del_Area"];

$querty=" INSERT INTO Areas (idArea,Nombre_Area,Division_Area,Detalles_del_Area) VALUES('$idArea','$Nombre_Area','$Division_Area','$Detalles_del_Area')";
$rep=sqlsrv_prepare($x,$querty);

if(sqlsrv_execute($rep)) 
{
    echo '<span style="color:white; font-size:21px;">¡¡¡Datos Ingresados Correctamente</span>';
    
    
}
 else 
 {
    echo '<span style="color:white; font-size:21px;">!!!Error Ingrese un idArea nuevo</span>';
 }
?>