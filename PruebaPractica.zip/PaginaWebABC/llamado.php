<?php
 require_once'base.php';
 include("ingreso.php");
 
 $idEmpleado=$_POST["idEmpleado"];
 $Nombre=$_POST["Nombre"];
 $ApellidoPaterno=$_POST["ApellidoPaterno"];
 $ApellidoMaterno=$_POST["ApellidoMaterno"];
 $Email=$_POST["Email"];
 $Area=$_POST["Area"];
$Division=$_POST["Division"]; 

$query=" INSERT INTO Empleados (idEmpleado,Nombre,ApellidoPaterno,ApellidoMaterno,Email,Area,Division) VALUES('$idEmpleado','$Nombre','$ApellidoPaterno','$ApellidoMaterno','$Email','$Area','$Division')";
$res=sqlsrv_prepare($x,$query);

if(sqlsrv_execute($res)) 
{
    echo '<span style="color:white; font-size:21px;">¡¡¡Datos Ingresados Correctamente</span>';
    
    
}
 else 
 {
    echo '<span style="color:white; font-size:21px;">!!!Error Ingrese un idEmpleado nuevo</span>';
 }
?>