<?php
 $server="LAPTOP-6LEN46OD";
 $conexion=array("Database"=>"ABC",
 "UID"=>"usrTest",
 "PWD"=>"usrPass",
 "CharacterSet"=>"UTF-8");

 $x=sqlsrv_connect($server,$conexion);
 
 if($x)
 {
    echo '<span style="color:white; font-size:20px;">....Conectado con la base de datos....</span>';
 }
 else{
    echo '<span style="color:white; font-size:20px;">No Conectado con la base de datos</span>';
 }
?>