<?php
require_once 'base.php';
$idArea=$_GET['id'];

$sql="DELETE FROM Areas WHERE idArea ='$idArea'";
$rta=sqlsrv_query($x,$sql);

    if(!$rta)
    {
        echo "No se Quito";
    }
    else
    {
        header("Location: AltaAreas.php");
    }
?>