<?php include("base.php")?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <meta charset="UTF-8">
    <title size=20>Base de datos ABC</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-u1OknCvxWvY5kfmNBILK2hRnQC3Pr17a+RTT6rIHI7NnikvbZlHgTPOOmMi466C8" crossorigin="anonymous"></script>
<style>
    body {
        background-color: grey;
    }
</style>
</head>
<body>
    <div class="container">
    <div class="row d-flex mt-8">
    <div class="col-3">
        <div class="center-block">
            <h4 class="text-center">INGRESAR EMPLEADO</h4>
        <form class="" action="llamado.php" method="post">
            
            <div class="from-group">
            <font size=4 color="black">
              <label for="">idEmpleado</label>
              </font>
              <input type="text" name ="idEmpleado" placeholder="Escriba solo el numero" value="" class="form-control">
            </div>

            <div class="from-group">
            <font size=4 color="black">
              <label for="">Nombre</label>
              </font>
              <input type="text" name ="Nombre"  value="" class="form-control">
            </div>

              <div class="from-group">
              <font size=4 color="black">
              <label for="">ApellidoPaterno</label>
              </font>
            <input type="text" name ="ApellidoPaterno"  value="" class="form-control">
            </div>

            <div class="from-group">
                <font size=4 color="black">
              <label for="">ApellidoMaterno</label>
              </font>
              <input type="text" name ="ApellidoMaterno" value="" class="form-control">
            </div>

            <div class="from-group">
            <font size=4 color="black">
              <label for="">Email</label>
              </font>
              <input type="text" name ="Email" value="" placeholder="ejem.abraham.vvv@gmail.com" class="form-control" >
            </div>

            <div class="from-group">
            <font size=4 color="black">
              <label for="">Area</label>
              </font>
              <input type="text" name ="Area" value="" class="form-control" >
            </div>

            <div class="from-group">
            <font size=4 color="black">
              <label for="">Division</label>
              </font>
              <input type="text" name ="Division" value="" class="form-control" >
            </div>

               <div class="row d-flex mt-3">
                 <div class="text-center">
                 <input type="submit" name ="" value="Guardar" class="btn btn-success" >
               </div>
            </div>
    </form>
        </div>
    </div>
       <div class="col-6">
       
          <h2 align=center>Empleados Registrados</h2>
          <table class="table">
            <thead class="table-success table-striped">
              <tr>
            <th>idEmpleado</th>
            <th>Nombre</th>
            <th>ApellidoPaterno</th>
            <th>ApellidoMaterno</th>
            <th>Area</th>
            <th>Division</th>
            <th>Email</th>
               </tr>
            </thead>
      <tbody>
            <?php
            $query="SELECT *FROM Empleados";
            $res=sqlsrv_query($x,$query);
            while($row=sqlsrv_fetch_array($res)){
              ?>
              <tr>
                <th><?php echo $row['idEmpleado']?></th>
                <th><?php echo $row['Nombre']?></th>
                <th><?php echo $row['ApellidoPaterno']?></th>
                <th><?php echo $row['ApellidoMaterno']?></th>
                <th><?php echo $row['Area']?></th>
                <th><?php echo $row['Division']?></th>
                <th><?php echo $row['Email']?></th>
                <th><a href="delete.php?id=<?php echo  $row['idEmpleado'] ?>" class="btn btn-danger">Eliminar</a></th>
              </tr>
              <?php
            }  
            ?>
            </tbody>
          </table>
        </div>
       </div>
    </div>
    </div>
    
</body>
</html>