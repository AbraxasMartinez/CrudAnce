<?php
require_once 'base.php';
$idEmpleado=$_GET['id'];

$sql="DELETE FROM Empleados WHERE idEmpleado ='$idEmpleado'";
$rta=sqlsrv_query($x,$sql);

    if(!$rta)
    {
        echo "No se Elimino";
    }
    else
    {
        header("Location: Ingreso.php");
    }
?>